//interact.c
//Handles user interactions, including input parsing and output formatting.
//Lauren Undseth 251351081

#include "interact.h"
#include "reminder.h"
#include "linked_list.h"
#include <stdio.h>

void readFromFile(void) {
    FILE* file = fopen("reminders.txt", "r"); // Open file for reading
    if (!file) {
        // File might not exist but return value
        return;
    }

    int day;
    char buffer[MAX_STR_LEN];
    while (fscanf(file, "%d:%[^\n]\n", &day, buffer) != EOF) {
        // Add the reminder to the corresponding day
        addNode(&month.reminders[day - 1], buffer);
    }

    fclose(file); // Close the file
}

void writeToFile(void) {
    FILE* file = fopen("reminders.txt", "w"); // Open file for writing
    if (!file) {
        perror("Failed to save reminders");
        return;
    }

    for (int day = 0; day < month.month_days; day++) {
        Node* current = month.reminders[day];
        while (current) {
            fprintf(file, "%d:%s\n", day + 1, current->reminder); // Save day and reminder
            current = current->next;
        }
    }

    fclose(file); // Close the file
}


