//linked_list.c
//Contains functions for managing linked lists of reminders for each day.
//lauren undseth 251351081 


#include "interact.h"
#include "reminder.h"
#include "linked_list.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Adds a reminder to the linked list for a day
void addNode(Node** head, const char* reminder) {
    Node* new_node = malloc(sizeof(Node));
    if (!new_node) {
        printf("Failed to allocate memory for a new node");
        return;
    }
    strncpy(new_node->reminder, reminder, MAX_STR_LEN);
    new_node->reminder[MAX_STR_LEN - 1] = '\0'; // Ensure null termination
    new_node->next = *head;
    *head = new_node;
}

// Frees all reminders from the linked list for a day
void freeAll(Node** head) {
    Node* temp;
    while (*head) {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}

// Prints all reminders for a specific day
void printList(Node* head) {
    while (head) {
        printf("- %s\n", head->reminder);
        head = head->next;
    }
}

