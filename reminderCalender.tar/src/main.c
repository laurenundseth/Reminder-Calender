//main.c
//Handles user input, interacts with the calendar, and manages reminders.
//Lauren Undseth 251351081


#include "reminder.h"
#include "interact.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>  


int main() {
    initializeMonth(); // Initialize the global mot=nth
    readFromFile();    // Load reminders from the file
    char reminder[MAX_STR_LEN];
    int day;

    while (1) {
        printf("\nEnter day and reminder (0 to quit): ");
        // Get whole line input and analyse the day and reminder separately
        if (!fgets(reminder, sizeof(reminder), stdin)) {
            printf("Error reading input. Please try again.\n");
            continue;
        }

        // Remove newline character if present
        if (reminder[strlen(reminder) - 1] == '\n') {
            reminder[strlen(reminder) - 1] = '\0';
        }

	//parse user input, if input doesnt match format, print error message
        if (sscanf(reminder, "%d %[^\n]", &day, reminder) < 1) {
            printf("Invalid input. Please try again.\n");
            continue;
        }// if statement to exit function
        if(day ==0) {
            printf("Exiting...\n");
            break;
	}

        if(day < 1 || day > 30) {
            printf("Invalid day:: The day must be >= 1 and <= 30 days\n");
            continue;
        }
        insertToCalendar(day, reminder);

	printCalendar(&month);
 	 printf("_____________________\n");
    }
    
    writeToFile(); // Save reminders before exiting
    return 0;
}

