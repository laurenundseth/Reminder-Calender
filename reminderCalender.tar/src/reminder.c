//reminder.c
//Implements functions for creating, managing, and deleting reminders.
//Lauren undseth 251351081

#include "reminder.h"
#include <stdio.h>
#include <time.h>

Month month; // Define the global Month variable

void initializeMonth(void) {
    time_t now = time(NULL);
    struct tm* t = localtime(&now);

    month.month_idx = 10;  // November
    t->tm_mon = month.month_idx;  // Ensure the month index is set correctly
    t->tm_mday = 1;  // Start with the first day of the month
    mktime(t);

    month.start_day = 5; // First day
    month.month_days = 30;

    // Initialize the reminders array
    for (int i = 0; i < 31; i++) {
        month.reminders[i] = NULL;
    }
}

// Function to get the day of the week as a string
const char* getDayOfWeek(int day_of_week) {
    switch (day_of_week) {
        case 0: return "Sun";
        case 1: return "Mon";
        case 2: return "Tue";
        case 3: return "Wed";
        case 4: return "Thu";
        case 5: return "Fri";
        case 6: return "Sat";
        default: return "";
    }
}
// Function to print reminders with numbers
void printRemindersWithNumbers(Node* head) {
    int reminder_number = 1;
    while (head) {
        printf(" (%d) %s", reminder_number, head->reminder);
        if (head->next) {
            printf("         \n"); // Separate reminders with newline
        }
        head = head->next;
        reminder_number++;
    }
    printf("\n");
}
void printCalendar(const Month* month) {
    printf("Sun Mon Tue Wed Thu Fri Sat\n");

    int day_of_week = month->start_day; // Start from the correct weekday
    for (int i = 0; i < day_of_week; i++) {
        printf("    ");
    }

    // Loop through all the days of the month
    for (int day = 1; day <= month->month_days; day++) {
        // Print dates with alignment
        if (month->reminders[day - 1]) {
            printf(" (%2d)", day);  // Add parentheses around the day number with a reminder
        } else {
            printf("  %2d", day);  // Print without parentheses for days without a reminder
        }

        // Move to the next day of the week
        day_of_week = (day_of_week + 1) % 7;

        // If it's Saturday, move to the next line
        if (day_of_week == 0) {
            printf("\n");
        }
    }

    // If the month does not end on Saturday, print a newline
    if (day_of_week != 0) {
        printf("\n");
    }

    // Print reminders for each day
    printf("\nNovember Reminders:\n");
    for (int day = 1; day <= month->month_days; day++) {
        if (month->reminders[day - 1]) {
            printf("%s %2d ::", getDayOfWeek((day + month->start_day - 1) % 7), day); // Print the correct weekday and day number
            printRemindersWithNumbers(month->reminders[day - 1]); // Assuming printRemindersWithNumbers prints the reminder
       	}
    }
}

// Inserts a reminder into the calendar for a specific day
void insertToCalendar(int day, const char* reminder) {
    if (day < 1 || day > month.month_days) {
        printf("Invalid day. Please enter a day between 1 and %d.\n", month.month_days);
        return;
    }
    addNode(&month.reminders[day - 1], reminder);
}

